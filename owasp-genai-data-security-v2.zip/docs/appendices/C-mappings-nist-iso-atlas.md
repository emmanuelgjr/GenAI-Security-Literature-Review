# Appendix C — Framework Mappings

Provide tables mapping each control (CTRL-*, AGT-*) to:
- NIST AI RMF functions
- ISO/IEC 42001 clauses
- MITRE ATLAS techniques
- OWASP LLM/Agentic Top 10 entries
